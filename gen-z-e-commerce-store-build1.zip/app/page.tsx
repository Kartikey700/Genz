'use client'

import { useMemo, useState } from 'react'
import {
  ArrowUpRight,
  ChevronDown,
  Heart,
  Menu,
  Minus,
  Plus,
  Search,
  ShoppingBag,
  Sparkles,
  Star,
  UserRound,
  X,
} from 'lucide-react'

const clothing = [
  { name: 'After Hours Hoodie', city: 'NEW YORK', price: 128, tag: 'BESTSELLER', image: '/editorial-collage.png' },
  { name: 'Concrete Uniform', city: 'LONDON', price: 96, tag: 'NEW DROP', image: '/editorial-collage.png' },
  { name: 'No Signal Tee', city: 'SEOUL', price: 54, tag: 'LIMITED', image: '/editorial-collage.png' },
]

const digital = [
  { name: 'Private Drop / Discord', detail: 'COMMUNITY ACCESS', price: 12, icon: 'D' },
  { name: 'The Creative Archive', detail: '256 DIGITAL ASSETS', price: 24, icon: 'A' },
  { name: 'Telegram Signal Pack', detail: 'WEEKLY EDITS', price: 8, icon: 'T' },
]

export default function Page() {
  const [cart, setCart] = useState(0)
  const [liked, setLiked] = useState<string[]>([])
  const [menuOpen, setMenuOpen] = useState(false)
  const [activeTab, setActiveTab] = useState<'clothing' | 'digital'>('clothing')
  const [showCart, setShowCart] = useState(false)
  const [showProfile, setShowProfile] = useState(false)
  const [credits, setCredits] = useState(240)

  const itemCount = useMemo(() => cart, [cart])
  const toggleLike = (name: string) => setLiked((current) => current.includes(name) ? current.filter((item) => item !== name) : [...current, name])

  return (
    <main className="min-h-screen overflow-hidden bg-[#f7f7f5] text-[#101010]">
      <div className="border-b border-black/10 bg-[#101010] px-4 py-2 text-center text-[10px] font-bold uppercase tracking-[0.2em] text-white sm:text-xs">
        Free shipping on orders over $150 · earn 2x shopping credits this week
      </div>

      <header className="sticky top-0 z-30 border-b border-black/10 bg-[#f7f7f5]/95 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-[1440px] items-center justify-between px-4 sm:px-8 lg:h-20 lg:px-12">
          <button aria-label="Open menu" className="lg:hidden" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button>
          <a href="#top" className="font-black tracking-[-0.08em] text-2xl sm:text-3xl">NO/FORM<span className="text-[#ff4d00]">.</span></a>
          <nav className={`${menuOpen ? 'flex' : 'hidden'} absolute left-0 top-full w-full flex-col gap-5 border-b border-black/10 bg-[#f7f7f5] px-5 py-6 text-sm font-bold uppercase tracking-widest lg:static lg:flex lg:w-auto lg:flex-row lg:border-0 lg:bg-transparent lg:p-0`}>
            <a href="#shop" onClick={() => setMenuOpen(false)} className="hover:opacity-60">Shop</a>
            <a href="#digital" onClick={() => setMenuOpen(false)} className="hover:opacity-60">Digital</a>
            <a href="#story" onClick={() => setMenuOpen(false)} className="hover:opacity-60">Our world</a>
            <a href="#dashboard" onClick={() => setMenuOpen(false)} className="hover:opacity-60">Dashboard</a>
          </nav>
          <div className="flex items-center gap-3 sm:gap-5">
            <button aria-label="Search" className="hidden sm:block hover:opacity-60"><Search size={19} /></button>
            <button aria-label="Profile" onClick={() => setShowProfile(true)} className="hover:opacity-60"><UserRound size={19} /></button>
            <button aria-label="Shopping bag" onClick={() => setShowCart(true)} className="relative hover:opacity-60"><ShoppingBag size={20} />{itemCount > 0 && <span className="absolute -right-2 -top-2 flex size-4 items-center justify-center rounded-full bg-[#ff4d00] text-[9px] font-bold text-white">{itemCount}</span>}</button>
          </div>
        </div>
      </header>

      <section id="top" className="mx-auto max-w-[1440px] px-4 pb-16 pt-7 sm:px-8 lg:px-12 lg:pb-24 lg:pt-10">
        <div className="grid gap-5 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="relative flex min-h-[560px] flex-col justify-between overflow-hidden bg-[#101010] p-6 text-white sm:p-10 lg:min-h-[680px] lg:p-14">
            <div className="relative z-10 flex items-start justify-between text-[10px] font-bold uppercase tracking-[0.22em]"><span>EST. 2024 / NYC—WORLDWIDE</span><span>001 / 005</span></div>
            <img src="/editorial-collage.png" alt="Monochrome editorial streetwear campaign" className="absolute inset-0 size-full object-cover opacity-55 mix-blend-screen" />
            <div className="relative z-10 max-w-3xl">
              <p className="mb-5 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-[#ff6a2c]"><Sparkles size={14} /> No rules, just form.</p>
              <h1 className="text-[clamp(4.5rem,10vw,10rem)] font-black uppercase leading-[0.78] tracking-[-0.095em]">Wear<br />your<br /><span className="text-[#ff6a2c]">signal.</span></h1>
              <p className="mt-8 max-w-sm text-sm leading-relaxed text-white/70">Uniforms for the digitally fluent. Physical pieces, private worlds, and the energy in between.</p>
            </div>
            <a href="#shop" className="relative z-10 flex w-fit items-center gap-3 border border-white/50 px-5 py-3 text-xs font-bold uppercase tracking-[0.18em] transition-colors hover:bg-white hover:text-black">Explore the drop <ArrowUpRight size={16} /></a>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-1">
            <div className="flex flex-col justify-between border border-black/15 bg-white p-6 sm:p-8 lg:min-h-[328px]">
              <div className="flex justify-between text-[10px] font-bold uppercase tracking-[0.2em]"><span>Dispatch / 01</span><span className="text-[#ff4d00]">Live now</span></div>
              <div><p className="mb-2 text-sm text-black/50">A new uniform for</p><h2 className="max-w-xs text-5xl font-black uppercase leading-[0.84] tracking-[-0.07em] sm:text-6xl">After<br />hours.</h2></div>
              <a href="#shop" className="mt-10 flex items-center justify-between border-t border-black/15 pt-4 text-xs font-bold uppercase tracking-widest">Shop the capsule <ArrowUpRight size={16} /></a>
            </div>
            <div className="relative flex min-h-[260px] flex-col justify-between overflow-hidden bg-[#d9d7d2] p-6 sm:p-8 lg:min-h-[328px]">
              <div className="relative z-10 flex justify-between text-[10px] font-bold uppercase tracking-[0.2em]"><span>For the inner circle</span><span>02</span></div>
              <div className="relative z-10"><h2 className="text-5xl font-black uppercase leading-[0.82] tracking-[-0.07em]">Digital<br /><span className="text-[#ff4d00]">goods.</span></h2><a href="#digital" className="mt-6 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest underline underline-offset-4">Enter the archive <ArrowUpRight size={14} /></a></div>
              <div className="absolute -bottom-14 -right-8 size-56 rounded-full border-[35px] border-[#101010]/10" />
            </div>
          </div>
        </div>
      </section>

      <section id="shop" className="border-y border-black/10 bg-white">
        <div className="mx-auto max-w-[1440px] px-4 py-16 sm:px-8 lg:px-12 lg:py-24">
          <div className="mb-10 flex flex-col justify-between gap-6 sm:flex-row sm:items-end"><div><p className="mb-3 text-[10px] font-bold uppercase tracking-[0.22em] text-[#ff4d00]">The current frequency</p><h2 className="text-5xl font-black uppercase tracking-[-0.08em] sm:text-7xl">The drop<span className="text-[#ff4d00]">.</span></h2></div><div className="flex border-b border-black/20 text-xs font-bold uppercase tracking-widest"><button onClick={() => setActiveTab('clothing')} className={`px-1 pb-3 mr-6 ${activeTab === 'clothing' ? 'border-b-2 border-black' : 'text-black/40'}`}>Clothing</button><button onClick={() => setActiveTab('digital')} className={`px-1 pb-3 ${activeTab === 'digital' ? 'border-b-2 border-black' : 'text-black/40'}`}>Digital</button></div></div>
          {activeTab === 'clothing' ? <div className="grid gap-4 md:grid-cols-3">{clothing.map((item, index) => <ProductCard key={item.name} item={item} index={index} liked={liked.includes(item.name)} onLike={() => toggleLike(item.name)} onAdd={() => setCart(cart + 1)} />)}</div> : <div id="digital" className="grid gap-4 md:grid-cols-3">{digital.map((item) => <DigitalCard key={item.name} item={item} onAdd={() => setCart(cart + 1)} />)}</div>}
        </div>
      </section>

      <section id="story" className="mx-auto grid max-w-[1440px] gap-8 px-4 py-16 sm:px-8 lg:grid-cols-2 lg:gap-20 lg:px-12 lg:py-28"><div><p className="mb-5 text-[10px] font-bold uppercase tracking-[0.22em] text-[#ff4d00]">A note from the studio</p><h2 className="max-w-xl text-5xl font-black uppercase leading-[0.85] tracking-[-0.08em] sm:text-7xl">Made for<br />the <span className="text-[#ff4d00]">in-between.</span></h2></div><div className="max-w-lg self-end"><p className="text-xl font-medium leading-snug sm:text-2xl">NO/FORM is a living wardrobe for people building their own frequency.</p><p className="mt-8 text-sm leading-relaxed text-black/55">We make fewer, better things. Every garment begins in a city, moves through a community, and ends up wherever you take it. Our digital drops keep the door open between releases.</p><a href="#dashboard" className="mt-8 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest underline underline-offset-4">Read the field notes <ArrowUpRight size={14} /></a></div></section>

      <section id="dashboard" className="border-t border-black/10 bg-[#101010] px-4 py-16 text-white sm:px-8 lg:px-12 lg:py-20"><div className="mx-auto max-w-[1440px]"><div className="mb-10 flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="mb-3 text-[10px] font-bold uppercase tracking-[0.22em] text-[#ff6a2c]">Your frequency</p><h2 className="text-4xl font-black uppercase tracking-[-0.07em] sm:text-6xl">Member dashboard<span className="text-[#ff6a2c]">.</span></h2></div><p className="max-w-xs text-sm text-white/50">The more you show up, the more the world opens up.</p></div><div className="grid gap-4 md:grid-cols-3"><div className="border border-white/20 p-6"><p className="text-[10px] font-bold uppercase tracking-widest text-white/50">Shopping credits</p><div className="mt-5 flex items-end gap-2"><span className="text-6xl font-black tracking-[-0.08em]">{credits}</span><span className="pb-2 text-sm text-[#ff6a2c]">pts</span></div><button onClick={() => setCredits(credits + 10)} className="mt-7 flex items-center gap-2 text-xs font-bold uppercase tracking-widest underline underline-offset-4">Check in +10 <ArrowUpRight size={14} /></button></div><div className="border border-white/20 p-6"><p className="text-[10px] font-bold uppercase tracking-widest text-white/50">Your referral code</p><div className="mt-5 flex items-center justify-between border border-white/20 px-4 py-3"><span className="font-mono text-lg font-bold">NOFORM-FAM</span><button className="text-[10px] font-bold uppercase tracking-widest text-[#ff6a2c]">Copy</button></div><p className="mt-5 text-xs leading-relaxed text-white/50">Give a friend 15% off. Get 250 credits when they join.</p></div><div className="border border-white/20 p-6"><p className="text-[10px] font-bold uppercase tracking-widest text-white/50">Account status</p><p className="mt-5 text-2xl font-black uppercase">Inner circle <span className="text-[#ff6a2c]">/ 02</span></p><div className="mt-6 h-1 bg-white/15"><div className="h-full w-2/3 bg-[#ff6a2c]" /></div><p className="mt-3 text-xs text-white/50">460 credits until next access level</p></div></div></div></section>

      <footer className="mx-auto flex max-w-[1440px] flex-col gap-8 px-4 py-10 sm:px-8 lg:flex-row lg:items-center lg:justify-between lg:px-12"><a href="#top" className="font-black tracking-[-0.08em] text-2xl">NO/FORM<span className="text-[#ff4d00]">.</span></a><p className="text-[10px] font-bold uppercase tracking-[0.2em] text-black/45">© 2024 NO/FORM. Built for the ones in motion.</p><div className="flex gap-5 text-[10px] font-bold uppercase tracking-widest"><a href="#digital">Discord</a><a href="#digital">Telegram</a><a href="#story">Contact</a></div></footer>

      {showCart && <Overlay title="Your bag" onClose={() => setShowCart(false)}><div className="flex flex-col gap-6"><div className="flex items-start justify-between border-b border-black/10 pb-5"><div><p className="font-black uppercase">Your current selection</p><p className="mt-1 text-sm text-black/50">{cart ? `${cart} item${cart === 1 ? '' : 's'} ready to go.` : 'Your bag is waiting for a signal.'}</p></div><ShoppingBag /></div><button onClick={() => setShowCart(false)} className="bg-[#101010] px-5 py-4 text-xs font-bold uppercase tracking-widest text-white">Continue shopping</button></div></Overlay>}
      {showProfile && <Overlay title="Member access" onClose={() => setShowProfile(false)}><div className="flex flex-col gap-4"><p className="text-sm text-black/60">Sign in to track orders, unlock digital drops, and grow your credits.</p><input placeholder="Email address" className="border border-black/20 bg-transparent px-4 py-4 text-sm outline-none placeholder:text-black/40" /><button onClick={() => setShowProfile(false)} className="bg-[#101010] px-5 py-4 text-xs font-bold uppercase tracking-widest text-white">Continue</button><p className="text-center text-[10px] font-bold uppercase tracking-widest text-black/40">New here? Create your profile</p></div></Overlay>}
    </main>
  )
}

function ProductCard({ item, index, liked, onLike, onAdd }: { item: typeof clothing[number]; index: number; liked: boolean; onLike: () => void; onAdd: () => void }) {
  return <article className="group"><div className="relative aspect-[0.82] overflow-hidden bg-[#deddd9]"><img src={item.image} alt={item.name} className={`size-full object-cover grayscale transition duration-700 group-hover:scale-105 ${index === 1 ? 'object-right' : ''}`} /><span className="absolute left-3 top-3 bg-white px-2 py-1 text-[9px] font-black uppercase tracking-widest">{item.tag}</span><button aria-label={`Save ${item.name}`} onClick={onLike} className="absolute right-3 top-3 rounded-full bg-white p-2"> <Heart size={16} fill={liked ? 'currentColor' : 'none'} /></button><button onClick={onAdd} className="absolute bottom-3 left-3 right-3 translate-y-16 bg-[#101010] px-4 py-3 text-xs font-bold uppercase tracking-widest text-white transition group-hover:translate-y-0">Add to bag +</button></div><div className="flex justify-between gap-3 pt-4"><div><p className="text-[10px] font-bold uppercase tracking-widest text-black/45">{item.city}</p><h3 className="mt-1 font-bold">{item.name}</h3></div><p className="font-bold">${item.price}</p></div></article>
}

function DigitalCard({ item, onAdd }: { item: typeof digital[number]; onAdd: () => void }) {
  return <article className="group border border-black/15 bg-[#f7f7f5] p-5"><div className="flex aspect-[1.2] items-center justify-center bg-[#101010] text-[9rem] font-black tracking-[-0.15em] text-white transition group-hover:bg-[#ff4d00]">{item.icon}</div><div className="flex items-end justify-between pt-5"><div><p className="text-[10px] font-bold uppercase tracking-widest text-black/45">{item.detail}</p><h3 className="mt-1 font-bold">{item.name}</h3></div><div className="text-right"><p className="font-bold">${item.price}</p><button onClick={onAdd} className="mt-2 text-[10px] font-bold uppercase tracking-widest underline underline-offset-4">Add +</button></div></div></article>
}

function Overlay({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return <div className="fixed inset-0 z-50 flex justify-end bg-black/40" onClick={onClose}><aside className="h-full w-full max-w-md bg-[#f7f7f5] p-6 sm:p-8" onClick={(event) => event.stopPropagation()}><div className="mb-12 flex items-center justify-between"><h2 className="text-3xl font-black uppercase tracking-[-0.06em]">{title}</h2><button aria-label="Close" onClick={onClose}><X /></button></div>{children}</aside></div>
}
