'use client'

import { FormEvent, useState } from 'react'
import { authClient } from '@/lib/auth-client'

export default function SignInPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [pending, setPending] = useState(false)

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (pending) return
    setPending(true)
    setError('')
    try {
      const result = await authClient.signIn.email({
        email: email.trim().toLowerCase(),
        password,
      })
      if (result.error) {
        setError('Unable to sign in. Check your details and try again.')
        return
      }
      window.location.assign('/')
    } catch {
      setError('Something went wrong. Please try again.')
    } finally {
      setPending(false)
    }
  }

  return <main className="flex min-h-screen items-center justify-center bg-[#f7f7f5] px-4 text-[#101010]"><form onSubmit={submit} className="w-full max-w-md border border-black/15 bg-white p-7 sm:p-10"><a href="/" className="text-2xl font-black tracking-[-0.08em]">NO/FORM<span className="text-[#ff4d00]">.</span></a><p className="mt-10 text-[10px] font-bold uppercase tracking-[0.22em] text-[#ff4d00]">Member access</p><h1 className="mt-3 text-5xl font-black uppercase leading-[0.85] tracking-[-0.08em]">Enter your<br />frequency.</h1><div className="mt-8 flex flex-col gap-3"><input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Email address" className="border border-black/20 bg-transparent px-4 py-4 text-sm outline-none focus:border-black" /><input required minLength={8} type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Password" className="border border-black/20 bg-transparent px-4 py-4 text-sm outline-none focus:border-black" /></div>{error && <p className="mt-3 text-xs text-[#ff4d00]">{error}</p>}<button disabled={pending} className="mt-5 w-full bg-[#101010] px-5 py-4 text-xs font-bold uppercase tracking-widest text-white disabled:opacity-50">{pending ? 'Connecting...' : 'Sign in'}</button><p className="mt-6 text-center text-xs text-black/50">New here? <a href="/sign-up" className="font-bold text-black underline underline-offset-4">Create your profile</a></p></form></main>
}
